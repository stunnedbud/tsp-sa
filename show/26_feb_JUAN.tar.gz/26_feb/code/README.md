# tsp-sa
Simulated Annealing Heuristic applied to the Travelling Salesman Problem (Julia implementation)
